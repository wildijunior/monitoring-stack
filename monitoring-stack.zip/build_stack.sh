#! /bin/bash

echo "================================"
echo "DEPLOYING MONITORING STACK"
echo "================================"
docker-compose up --build
